#!/usr/bin/env python3
plans = [
    {"id":"day","name":"Pass Jour","amount":10000,"currency":"GNF","duration_hours":24},
    {"id":"month","name":"Pass Mois","amount":150000,"currency":"GNF","duration_hours":720},
    {"id":"year","name":"Pass Année","amount":1500000,"currency":"GNF","duration_hours":8760},
]
print(plans)
